import { Component, OnInit } from '@angular/core';
export class User {
  constructor(
    public id: number,
    public description: string,
    public targetDate:Date,
    public isCompleted:boolean
  ) {

  }
}


@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.css']
})
export class ListUsersComponent implements OnInit {
  users = [
    new User(1, 'welcome 1',new Date(),false),
    new User(2, 'welcome 2',new Date(),false),
    new User(3, 'welcome 3',new Date(),false),
    new User(4, 'welcome 4',new Date(),false)
  ]
  constructor() { }

  ngOnInit() {
  }

}
