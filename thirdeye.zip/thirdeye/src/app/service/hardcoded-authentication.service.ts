import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthenticationService {

  constructor() { }

  authenticate(username: string, password: string): boolean {
   //console.log('before'+this.isUserLoggerIn())
    if (username === 'vivek' && password === '1234') {
      sessionStorage.setItem('authenticateUser', username);
      return true
    }
    else {
      return false
    }
  }
  isUserLoggerIn():boolean{
    let user=sessionStorage.getItem('authenticateUser')
  return !(user==null)
  }
  logoutUser():void{
    sessionStorage.removeItem('authenticateUser')
  }
}
