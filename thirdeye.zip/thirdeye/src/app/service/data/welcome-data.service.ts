import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UsermanagementApis } from 'src/app/constant/usermanagement-apis';
export class HelloWorld{
  constructor(public message:string){}
}
@Injectable({
  providedIn: 'root'
})
export class WelcomeDataService {

  constructor(
    private http:HttpClient
  ) { }
getWelcomemMsg(){
return this.http.get<HelloWorld>(UsermanagementApis.WELCOME_API_ENDPOINT);
}
}
