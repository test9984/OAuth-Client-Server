import { TestBed } from '@angular/core/testing';

import { PermissionDataService } from './permission-data.service';

describe('PermissionDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PermissionDataService = TestBed.get(PermissionDataService);
    expect(service).toBeTruthy();
  });
});
