import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PermissionDataService {

  constructor() { }

getAllPermissions(){
  console.log("permission service")
}
}
