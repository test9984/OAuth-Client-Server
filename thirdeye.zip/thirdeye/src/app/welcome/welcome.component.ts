import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WelcomeDataService } from '../service/data/welcome-data.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
welcomeMessage:string
  username=''
  constructor(private router:ActivatedRoute,private welcomeService:WelcomeDataService ) { }

  ngOnInit() {
    this.username=this.router.snapshot.params['name']
  }
  getWelcomeMsg(){
    this.welcomeService.getWelcomemMsg().subscribe(
      response=>this.handleSuccessFullResponse(response),
      error=>this.handleErrorResponse(error)
    );
  }

  handleSuccessFullResponse(response){
    this.welcomeMessage=response.message
  }
  handleErrorResponse(error){
    this.welcomeMessage=error.error.message
  }
}
