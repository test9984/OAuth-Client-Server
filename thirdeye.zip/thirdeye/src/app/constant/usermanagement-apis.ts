export class UsermanagementApis {
    public static WELCOME_API_ENDPOINT='http://localhost:9092/user-management/welcome';

}
