import { UsermanagementApis } from './usermanagement-apis';

describe('UsermanagementApis', () => {
  it('should create an instance', () => {
    expect(new UsermanagementApis()).toBeTruthy();
  });
});
